@extends('spark::layouts.app') @section("title") Home @endsection @section('breadcrumb')
<h1>Home</h1>
<ol class="breadcrumb">
    <li>
        <a href="/home">
            <i class="livicon" data-name="home" data-size="14" data-loop="true"></i> Home
        </a>
    </li>
</ol>
@endsection @section('content')
<home :user="user" inline-template>
    <div>
        <!-- Application Dashboard -->
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-success">
                    <div class="panel-heading"><i class="livicon" data-name="home" data-size="18" data-loop="true" data-color="#fff" data-hc="#fff"></i> Dashboard</div>
                    <div class="panel-body">
                        Your application's dashboard.
                    </div>
                </div>
            </div>
        </div>
    </div>
</home>
@endsection
