var base = require('settings/invoices');

Vue.component('spark-invoices', {
    mixins: [base]
});
