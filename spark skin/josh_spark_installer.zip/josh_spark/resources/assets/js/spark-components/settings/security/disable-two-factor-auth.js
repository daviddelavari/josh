var base = require('settings/security/disable-two-factor-auth');

Vue.component('spark-disable-two-factor-auth', {
    mixins: [base]
});
