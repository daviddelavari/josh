var base = require('auth/register-stripe');

Vue.component('spark-register-stripe', {
    mixins: [base]
});
