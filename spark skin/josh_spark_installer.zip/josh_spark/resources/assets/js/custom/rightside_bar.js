"use strict";
(function(window) {
    // Is Modernizr defined on the global scope
    var Modernizr = typeof Modernizr !== "undefined" ? Modernizr : false,
        // whether or not is a touch device
        isTouchDevice = Modernizr ? Modernizr.touch : !!('ontouchstart' in window || 'onmsgesturechange' in window),
        // Are we expecting a touch or a click?
        buttonPressedEvent = (isTouchDevice) ? 'touch' : 'click',
        joshui = function() {
            this.init();
        };
    // Initialization method
    joshui.prototype.init = function() {
        this.isTouchDevice = isTouchDevice;
        this.buttonPressedEvent = buttonPressedEvent;
    };
    joshui.prototype.getViewportHeight = function() {
        var docElement = document.documentElement,
            client = docElement.clientHeight,
            inner = window.innerHeight;
        if (client < inner)
            return inner;
        else
            return client;
    };
    joshui.prototype.getViewportWidth = function() {
        var docElement = document.documentElement,
            client = docElement.clientWidth,
            inner = window.innerWidth;
        if (client < inner)
            return inner;
        else
            return client;
    };
    // Creates a clear object.
    window.joshui = new joshui();
})(window);
(function($) {
    var $navBar = $('nav.navbar'),
        $body = $('body'),
        $menu = $('#menu');

    function getHeight(el) {
        return el.outerHeight();
    }

    function init() {
        var isFixedNav = $navBar.hasClass('navbar-fixed-top');
        var bodyPadTop = isFixedNav ? $navBar.outerHeight(true) : 0;
        $body.css('padding-top', bodyPadTop);
    }

    joshui.navBar = function() {
        var resizeTimer;
        init();
        $(window).on('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(init(), 250);
        });
    };
    return joshui;
})(jQuery);
(function($, joshui) {
    var $body = $('body'),
        $rightToggle = $('.toggle-right');
    joshui.clearAnimatePanel = function() {
        if ($('#right').length) {
            $rightToggle.on("click", function(e) {
                switch (true) {
                    // Close right panel
                    case $body.hasClass("sidebar-right-opened"):
                        {
                            $body.removeClass("sidebar-right-opened");
                            if ($body.hasClass("boxed")) {
                                $('#right').css('right', '-270px');
                            }
                            break;
                        }
                    default:
                        // Open right panel
                        {
                            // Open right panel
                            $body.addClass("sidebar-right-opened");
                            adjust_boxright();
                            $('.navbar-nav>.dropdown').removeClass("open");
                        }
                }
                e.preventDefault();
            });
        } else {
            $rightToggle.addClass('hidden');
        }
    };
    return joshui;
})(jQuery, joshui || {});
$(window).on('resize', function() {
    adjust_boxright();
});

function adjust_boxright() {
    if ($('body').hasClass('boxed') && $("body").hasClass("sidebar-right-opened")) {
        var window_w = $(window).width();
        var body_w = $('body').width();
        var margin_right = (window_w - body_w) / 2;
        $('#right').css('right', margin_right);
    }
}
(function($) {
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
        joshui.navBar();
        joshui.clearAnimatePanel();
    });
})(jQuery);

// ===========rightside bar hide on blur ========
$(document).click(function(e) {
    var container = $("#right,.dropdown-toggle.toggle-right");
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        $('body').removeClass("sidebar-right-opened");
        if ($("body").hasClass("boxed")) {
            $('#right').css('right', '-270px');
        }
    }
});
// ===========rightside bar hide on blur ends ========

$('.navbar-nav>.dropdown').on('click', function() {
    $('body').removeClass("sidebar-right-opened");
    if ($("body").hasClass("boxed")) {
        $('#right').css('right', '-270px');
    }
});

//slim scroll for right side bar
$('#right-slim').slimscroll({
    height: '100vh',
    size: '3px',
    color: '#6699cc',
    opacity: .4
});
