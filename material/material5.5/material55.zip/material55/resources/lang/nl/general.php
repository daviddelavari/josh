<?php
/**
* Language file for general strings
*
*/
return array(

    'no'  			=> 'Nee',
    'noresults'  	=> 'Geen resultaten',
    'yes' 			=> 'Ja',
    'site_name'     => 'Pagina Naam'

);
