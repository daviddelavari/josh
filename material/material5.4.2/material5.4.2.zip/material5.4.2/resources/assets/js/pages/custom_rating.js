/**
 * Created by user on 7/6/16.
 */

$('.rating').rating({
    size:'sm'
});
