$(document).ready(function() {
    $.material.init();
    $('#summernote').summernote();
    $('#slimscrollside').slimscroll({
        height: '700px',
        size: '3px',
        color: 'black',
        opacity: .3

    });
});
