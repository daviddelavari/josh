josh_html
=========
|S.NO  |Color Names   | Color Code  
|------|--------------|:-------------------:|
| 1    | Primary      |  #418BCA            | 
| 2    | Success      |  #01BC8C            | 
| 3    | Info         |  #67C5DF            | 
| 4    | Warning      |  #F89A14            | 
| 5    | Danger       |  #EF6F6C            |
| 6    | Default      |  #A9B6BC            |




|S.NO  |Plugins URL                                                    |   Used Pages     
|------|---------------------------------------------------------------|:-------------------:|
| 1    | https://github.com/IhabSoliman/Bootstrap-Form-Builder         |  form_builder.html  | 
| 2    | https://github.com/frappe/bootstrap-form-builder              |  form_builder2.html | 
| 3    | https://github.com/IhabSoliman/Bootstrap-Form-Builder         |  buttonbuilder.html | 
| 4    | https://github.com/neokoenig/jQuery-gridmanager               |  gridmanager.html   | 
| 5    | http://ckeditor.com/demo                                      |  editor.html        |
| 6    | http://www.tinymce.com/                                       |  gridmanager.html, editor.html| 
| 7    | https://github.com/xing/wysihtml5                             |editor.html, add_newblog.html, compose.html,
|      |                                                               |forward.html,reply.html | 
| 8    | http://jasny.github.io/bootstrap/                             |  validation.html | 
| 9    | http://bootstrapvalidator.com/                                |  validation.html,formwizard.html | 
| 10   | https://github.com/fronteed/iCheck/                           |formelements.html| 
| 11   | https://github.com/RobinHerbots/jquery.inputmask              |formelements.html| 
| 12   | https://github.com/davidstutz/bootstrap-multiselect           |formelements.html | 
| 13   | https://github.com/petkaantonov/jQuery-autogrow               |formelements.html | 
| 14   | https://github.com/mimo84/bootstrap-maxlength                 |formelements.html| 
| 15   | https://github.com/t0m/select2-bootstrap-css/tree/bootstrap3  |formelements.html,advanced_tables.html,editable_table.html,
|      |                                                               |form_layouts.html,transitions.html,x-editable.html| 
| 16   |https://github.com/rstaib/jquery-steps                         |formwizard.html|


 


