$(document).ready(function() {
    $.material.init();
    $('#summernote').summernote();
// $("#category").select2({
//     theme: "bootstrap"
// });
//     $("#selecttag").select2({
//         tags: true,
//         tokenSeparators: [',', ' '],
//         theme: "bootstrap",
//         width:"100%",
//         placeholder:"tags"
//     })
});